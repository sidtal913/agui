# Middleware Starter

This starter kit demonstrates how to set up a middleware server that can be used to proxy events from the agent to the frontend.

## Tutorial

To learn how to set up your own middleware server, please refer to the [tutorial](https://docs.ag-ui.com/quickstart/middleware).
