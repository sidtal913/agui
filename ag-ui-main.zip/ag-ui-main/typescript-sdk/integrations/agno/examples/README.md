Extracted from with-agno

To install deps
pip install -r requirements.txt

to run 
python agent.py