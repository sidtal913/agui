/**
 * Agno is a framework for building Multi-Agent Systems with memory, knowledge and reasoning.
 * Check more about using Agno: https://docs.agno.com/
 */

import { HttpAgent } from "@ag-ui/client";

export class AgnoAgent extends HttpAgent {}
