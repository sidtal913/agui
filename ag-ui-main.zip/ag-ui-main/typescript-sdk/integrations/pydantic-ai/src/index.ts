import { HttpAgent } from "@ag-ui/client";

export class PydanticAIAgent extends HttpAgent {}
