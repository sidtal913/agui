import { HttpAgent } from "@ag-ui/client";

export class CrewAIAgent extends HttpAgent {}
