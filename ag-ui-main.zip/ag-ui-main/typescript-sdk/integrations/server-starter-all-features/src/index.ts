import { HttpAgent } from "@ag-ui/client";

export class ServerStarterAllFeaturesAgent extends HttpAgent {}
