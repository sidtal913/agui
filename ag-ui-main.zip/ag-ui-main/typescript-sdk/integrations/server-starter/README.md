# Server Starter

This starter kit demonstrates sending the minimal set of events that are needed to stream data from the agent to the frontend.

## Running the server

To run the server:

```bash
cd typescript-sdk/integrations/server-starter/server/python

poetry install && poetry run dev
```
