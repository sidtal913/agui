import { HttpAgent } from "@ag-ui/client";

export class ServerStarterAgent extends HttpAgent {}
