import { HttpAgent } from "@ag-ui/client";

export * from './agent'
export class LangGraphHttpAgent extends HttpAgent {}