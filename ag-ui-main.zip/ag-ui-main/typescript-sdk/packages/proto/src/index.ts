export { encode, decode } from "./proto";

export const AGUI_MEDIA_TYPE = "application/vnd.ag-ui.event+proto";
