describe("Core package", () => {
  it("should pass a simple test", () => {
    expect(true).toBe(true);
  });
});
