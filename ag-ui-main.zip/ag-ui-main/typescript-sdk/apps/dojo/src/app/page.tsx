"use client";

import React from "react";

export default function Home() {
  return (
    <div className="flex-1 h-screen w-full flex flex-col items-center justify-center p-8">
      <h1 className="text-base font-normal text-muted-foreground mb-4">
        Select an integration to get started
      </h1>
    </div>
  );
}
