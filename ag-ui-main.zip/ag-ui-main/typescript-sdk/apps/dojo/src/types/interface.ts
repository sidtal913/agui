export type View = "preview" | "code" | "readme";
